﻿Function New-EmployeeOnboardUser{
    <#
        .SYNOPSIS
           This function is a part of the Active Directory Account Management Automator tool. It is used to perform all routine
           tasks that must be done when onboarding a new employee user account.
       
        .EXAMPLE
            PS> New-EmployeeOnboardUser -FirstName 'Adam' -MiddleIntialName 'D' -LastName 'Betram' -Title 'Dr. Awsome'

            This example creates an AD username based on company standards into a company-standard OU and adds the user
            into the Company-standard main user group.

        .PARAMETER FirstName
            The first name of the employee.

        .PARAMATER MiddleIntialName
            The middle name of the employee.

        .PARAMETER LastName 
            The last name of the employee

        .PARAMETER Title
            The current job title of the employee
        #>
        [CmdletBinding()]
        param (
            [string]$FirstName,
            [string]$MiddleIntial,
            [string]$LastName,
            [string]$Location = 'OU=Corporate Users',
            [string]$Title
        )
        process {
            ## Not the best use of storing the password clear text
            ## Google/Bing on using stored secure strings on the file system as a way to get around this
            $DefaultPassword = 'india@123'
            $Domainon = (Get-AdDomain).DistinguishedName
            $DefaulGroup = 'SecurityGroup-inter'

            ## Figure ouy what the username Should be
            $UserName = "$($FirstName.SubString(0,1))$LastName"
            ## Check if an existing user already has the first initial/last name username taken
            
            $ErrorActionPreference = 'SilentlyContinue'
             try{
                if (Get-AdUser -Identity $UserName){
                     ## if so, check to see if the first initial/middle initial/last name is taken.
                     $UserName = "$($FirstName.SubString(0,1))$MiddleInitial$LastName"
                     if(Get-AdUser $UserName){
                     throw "No Acccesptable username schema could be created"
                   }
                }
             } catch {
                Write-Error $_.Exception.Message
             }
           
            ##Create the user account
            
            $NewUserParams = @{
                'UserPrincipalName' = $UserName
                'Name' = $UserName
                'GivenName' = $FirstName
                'Surname' = $LastName
                'Title' = $Tittle
                'SamAccountName' = $UserName
                'AccountPassword' = (ConvertTo-SecureString $DefaultPassword -AsPlainText -Force)
                'Enabled' = $true
                'Initials' = $MiddelInitial
                'Path' = "$Location,$Deomainon"
                'ChangePasswordAtLogon' = $true
            }

            New-AdUser @NewUserParams

            ##Add the user account to the company standard Group

            Add-ADGroupMember -Identity $DefaulGroup -Members $UserName
            $UserName
        
     }
}

Function Set-MyAdUser{
            <#
            .SYNOPSIS
               This function is a part of the Active Directory Account Management Automator tool. It is used to perform all routine
               tasks that must be done when Modifying a employee user account.
       
            .EXAMPLE
                PS> Set-MyAdUser -Username 'rathodv' -Attributes @{'givenName' = 'Venki'; 'DisplayName'= 'venkatesh rathod';'Title'= 'Manager'}

                This example Changes the givenname to venki, the display name to 'venkatesh rathod' and the title to 'Manager' for the username 'rathodv'

            .PARAMETER UserName
                An Active Directory username to modify

            .PARAMATER Attributes
                A hashtable with keys as Set-AdUser parameter values and values as Set-AdUser parameter argument values.
            #>
            [CmdletBinding()]
            param(
                [string]$Username,
                [hashtable]$Attributes 
            )
            process {
                try {
                    ## Attempt to find the username
                    $UserAccount = Get-AdUser -Identity $Username
                    if (!$UserAccount){
                    ## If the Username isn't found throw an error and exit
                    throw "The Username '$username'does not exist"
                    }
                } catch {
                     Write-Error $_.Exception.Message     
                }
            ## The $Attribute parameter will contain only the parameters for the Set-AdUser cmdlet other than
            ## Password. If this is in $Attributes it needs to be treated differently.

            if ($Attributes.ContainsKey('Password')){
               $UserAccount | Set-ADAccountPassword -Reset -NewPassword (ConvrtTo-SecureString - AsPlainTest $Attributes.Password -Force)
               ## Remove the paasword key because we'll be passing this hastable directly to Set-AdUser later
            }

            $UserAccount | Set-AdUser @Attributes
            }

}

Function Set-MyAdComputer{
            <#
            .SYNOPSIS
               This function is a part of the Active Directory Account Management Automator tool. It is used to perform all routine
               tasks that must be done when Modifying a Computer attribute.
       
            .EXAMPLE
                PS> Set-MyAdComputer -Computername 'rathodvcomputer' -Attributes @{'Description'= 'This is venkatesh Computer'}

                This example Changes the Computer Description to 'This is venkatesh Computer' of the 'rathodvcomputer' computer

            .PARAMETER Computername
                An Active Directory computername to be modify

            .PARAMATER Attributes
                A hashtable with keys as Set-MyAdComputerr parameter values and values as Set-MyAdComputer parameter argument values.
            #>
            [CmdletBinding()]
            param(
                [string]$Computername,
                [hashtable]$Attributes 
            )
            process {
            try{
               $Computer = Get-AdComputer -Identity $Computername
               if (!$Computer){
   
               ## if the ComputerName Isn't found throw and error and exit
               throw "The Computername '$Computername' does not exist"
               }
               } catch{
               Write-Error $_.Exception.Message 
             }

            ## The $Attributes paramter will contain only the parameters for the Set-AdComputer cmdlet
            $Computer | Set-AdComputer @Attributes
     }
}

Function New-EmployeeOnboardComputer{
            <#
            .SYNOPSIS
               This function is a part of the Active Directory Account Management Automator tool. It is used to perform all routine
               tasks that must be done when Modifying a Computer attribute.
       
            .EXAMPLE
                PS> Set-MyAdComputer -Computername 'rathodvcomputer' -Attributes @{'Description'= 'This is venkatesh Computer'}

                This example Changes the Computer Description to 'This is venkatesh Computer' of the 'rathodvcomputer' computer

            .PARAMETER Computername
                An Active Directory computername to be modify

            .PARAMATER Attributes
                A hashtable with keys as Set-MyAdComputerr parameter values and values as Set-MyAdComputer parameter argument values.
            #>
            parma(
            [string]$ComputerName,
            [string]$Location = 'OU=Corporate Computers'
            )
            Process{
            try{
               if (Get-ADComputer $ComputerName){
               throw "The Computer Name '$ComputerName' Already Exists"
             }
            } catch{
                Write-Error $_.Exception.Message 
            }

            $DomainOn = (Get-ADDomain).DistinguishedName
            $DefaultOuPath = "$Location,$DomainOn"

            New-ADComputer -Name $ComputerName -Path $DefaultOuPath
            }
}